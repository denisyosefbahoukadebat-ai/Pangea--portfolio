const pages=[...document.querySelectorAll('.page')];
function go(id){pages.forEach(p=>p.classList.toggle('active',p.id===id));location.hash=id;scrollTo({top:0,behavior:'smooth'})}
document.querySelectorAll('[data-go]').forEach(x=>x.addEventListener('click',()=>go(x.dataset.go)));
const id=location.hash.slice(1);if(id&&document.getElementById(id))go(id);